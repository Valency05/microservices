package com.cognizant.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.banking.dtos.AccountDTO;
import com.cognizant.banking.dtos.AccountResponse;
import com.cognizant.banking.dtos.GenericMessage;
import com.cognizant.banking.entities.Account;
import com.cognizant.banking.entities.AccountType;
import com.cognizant.banking.mappers.AccountMapper;
import com.cognizant.banking.services.AccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/accounts")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class AccountController {

	@Autowired
	private AccountService accountService;

	@Autowired
	private AccountMapper accountMapper;

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@PostMapping("/v1.0")
	public ResponseEntity<GenericMessage> addAccount(@Valid @RequestBody AccountDTO dto) {

		Account toSave = accountMapper.toEntity(dto);
		Account saved = accountService.addAccount(toSave);
		AccountResponse response = accountMapper.toDTO(saved);

		return ResponseEntity.status(HttpStatus.CREATED).body(new GenericMessage(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping("/v1.0")
	public List<AccountResponse> getAllAccounts() {
		return accountMapper.toDTOs(accountService.getAllAccounts());
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping("/v1.0/{id}")
	public ResponseEntity<GenericMessage> getAccountById(@PathVariable("id") Long id) {
		Account account = accountService.getAccountById(id);
		AccountResponse response = accountMapper.toDTO(account);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping(value = "/v1.0/search", params = "accountNumber")
	public ResponseEntity<GenericMessage> getAccountByAccountNumber(@RequestParam String accountNumber) {
		Account account = accountService.getAccountByAccountNumber(accountNumber);
		return ResponseEntity.ok(new GenericMessage(accountMapper.toDTO(account)));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@PatchMapping("/v1.0")
	public ResponseEntity<GenericMessage> updateAccountType(@RequestParam Long id,
			@RequestParam AccountType type) {

		Account updated = accountService.updateAccount(id, type);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage(accountMapper.toDTO(updated)));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@DeleteMapping("/v1.0")
	public ResponseEntity<GenericMessage> deleteAccount(@RequestParam Long id) {
		boolean deleted = accountService.deleteAccount(id);
		if (deleted) {
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage(id));
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new GenericMessage(id));
		}
	}
}