package com.cognizant.banking.services;

import java.util.List;

import com.cognizant.banking.entities.Account;
import com.cognizant.banking.entities.AccountType;


public interface AccountService {
	Account addAccount(Account account);

	List<Account> getAllAccounts();

	Account getAccountById(Long id);

	Account getAccountByAccountNumber(String accountNumber);

	Account updateAccount(Long id, AccountType type);

	boolean deleteAccount(Long id);

}