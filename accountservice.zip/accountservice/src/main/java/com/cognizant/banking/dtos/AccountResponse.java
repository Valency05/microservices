package com.cognizant.banking.dtos;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import com.cognizant.banking.entities.AccountType;

public record AccountResponse(Long id, String accountNumber, Long customerId,
				AccountType type, BigDecimal balance, OffsetDateTime createdAt) {

}