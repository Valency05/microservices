package com.cognizant.banking.exceptions;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cognizant.banking.dtos.GenericMessage;



@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(AccountNullException.class)
    public ResponseEntity<GenericMessage> handleCustomerNullException(AccountNullException ex) {
    	String errorMessage = "Customer id is not found";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new GenericMessage(errorMessage));
    }

    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<GenericMessage> handleCustomerNotFoundException(AccountNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new GenericMessage(ex.getMessage()));
    }

}