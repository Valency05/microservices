package com.cognizant.banking.repositories;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cognizant.banking.entities.Account;

public interface AccountRepository extends JpaRepository<Account, Long> {
	boolean existsByAccountNumber(String accountNumber);

	Optional<Account> findByAccountNumber(String accountNumber);
}