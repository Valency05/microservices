package com.cognizant.banking.entities;

public enum AccountType {
	Savings, Current, Checking, Loan
}