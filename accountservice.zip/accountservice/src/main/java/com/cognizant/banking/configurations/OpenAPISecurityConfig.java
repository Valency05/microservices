package com.cognizant.banking.configurations;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.OAuthFlow;
import io.swagger.v3.oas.models.security.OAuthFlows;
import io.swagger.v3.oas.models.security.Scopes;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;

@Configuration
public class OpenAPISecurityConfig {

    @Value("${keycloak.issuer}")
    String issuer;

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
            .components(new Components()
                .addSecuritySchemes("keycloakDEVELOPER", oauthScheme("developer", "DEVELOPER access"))
                .addSecuritySchemes("keycloakDevOpsEngineer", oauthScheme("devopsengineer", "Devops Engineer access"))
            )
            // Don't force both scopes; Swagger will let you choose which scheme to authorize
            .addSecurityItem(new SecurityRequirement().addList("keycloakDEVELOPER"))
            .addSecurityItem(new SecurityRequirement().addList("keycloakDevOpsEngineer"))
            .info(new Info()
                .title("Account Management Service")
                .description("Account API with OAuth2 Security")
                .version("1.0"));
    }

    private SecurityScheme oauthScheme(String scope, String desc) {
        String authUrl  = issuer + "/protocol/openid-connect/auth";
        String tokenUrl = issuer + "/protocol/openid-connect/token";

        OAuthFlow code = new OAuthFlow()
            .authorizationUrl(authUrl)
            .tokenUrl(tokenUrl)
            .scopes(new Scopes().addString(scope, desc));

        return new SecurityScheme()
            .type(SecurityScheme.Type.OAUTH2)
            .flows(new OAuthFlows().authorizationCode(code));
    }
}