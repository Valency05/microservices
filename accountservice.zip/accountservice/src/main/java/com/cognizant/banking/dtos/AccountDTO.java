package com.cognizant.banking.dtos;

import java.math.BigDecimal;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class AccountDTO {
	@NotBlank
	@Pattern(regexp = "^[A-Z0-9]{10,22}$", message = "Account number must be 10-22 uppercase alphanumeric")
	private String accountNumber;

	@NotNull
	@Positive
	private Long customerId;

	@NotBlank
	@Pattern(regexp = "Savings|Current|Checking|Loan", message = "type must be one of Savings|Current|Checking|Loan")
	private String type;

	@NotNull
	@DecimalMin(value = "0.00", message = "balance cannot be negative")
	private BigDecimal balance;
}