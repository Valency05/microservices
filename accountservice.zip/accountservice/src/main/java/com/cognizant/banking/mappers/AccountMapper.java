package com.cognizant.banking.mappers;

import java.util.List;

import org.mapstruct.Mapper;

import com.cognizant.banking.dtos.AccountDTO;
import com.cognizant.banking.dtos.AccountResponse;
import com.cognizant.banking.entities.Account;

@Mapper(componentModel = "spring")
public interface AccountMapper {

	Account toEntity(AccountDTO dto);

	AccountResponse toDTO(Account entity);

	List<AccountResponse> toDTOs(List<Account> entities);
}