package com.cognizant.banking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayappApplicationTests {

	@Test
	void contextLoads() {
	}

}
