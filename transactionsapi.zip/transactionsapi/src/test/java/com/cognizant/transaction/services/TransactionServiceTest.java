package com.cognizant.transaction.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClient;

import com.cognizant.transaction.models.Transaction;
import com.cognizant.transaction.models.TransactionStatus;
import com.cognizant.transaction.models.TransactionType;
import com.cognizant.transaction.repositories.TransactionRepository;
import com.cognizant.transaction.services.TransactionServiceImpl;
import com.github.javafaker.Faker;

@ExtendWith(MockitoExtension.class)
public class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private RestClient restClient;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    @Test
    public void addTransactionMockTest() {
        Transaction transaction = new Transaction();
        transaction.setId(201L);
        transaction.setAccountId(500L);
        transaction.setAmount(new BigDecimal("250.00"));
        transaction.setType(TransactionType.Deposit); // Assuming Enum exists
        transaction.setStatus(TransactionStatus.PENDING);

//        RestClient.RequestHeadersUriSpec uriSpec = Mockito.mock(RestClient.RequestHeadersUriSpec.class, Mockito.RETURNS_DEEP_STUBS);
//        when(restClient.get()).thenReturn(uriSpec);
//        
//        when(uriSpec.uri(anyString(), anyLong())
//            .headers(any())
//            .retrieve()
//            .onStatus(any(), any())
//            .toBodilessEntity()
//            .getStatusCode()
//            .is2xxSuccessful()).thenReturn(true);
        
        when(transactionRepository.save(any(Transaction.class))).thenReturn(transaction);

        Transaction response = transactionService.addTransaction(transaction);

        assertNotNull(response);
        assertEquals(201L, response.getId());
        assertEquals(TransactionStatus.PENDING, response.getStatus());
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }

    @Test
    public void getAllTransactionsMockTest() {
        List<Transaction> transactions = getMockTransactions();
        when(transactionRepository.findAll()).thenReturn(transactions);

        List<Transaction> response = transactionService.getAllTransactions();

        assertEquals(transactions.size(), response.size());
    }

    @Test
    public void getTransactionByIdMockTest() {
        Transaction transaction = getMockTransactions().get(0);
        Long id = transaction.getId();

        when(transactionRepository.findById(id)).thenReturn(Optional.of(transaction));

        Transaction response = transactionService.getTransactionById(id);

        assertNotNull(response);
        assertEquals(id, response.getId());
    }

    @Test
    public void getTransactionsByAccountIdMockTest() {
        Long accountId = 500L;
        List<Transaction> transactions = getMockTransactions();
        when(transactionRepository.findByAccountId(accountId)).thenReturn(transactions);

        List<Transaction> response = transactionService.getTransactionsByAccountId(accountId);

        assertFalse(response.isEmpty());
        verify(transactionRepository, times(1)).findByAccountId(accountId);
    }

    @Test
    public void updateTransactionAmountMockTest() {
        Transaction existingTransaction = getMockTransactions().get(0);
        Long id = existingTransaction.getId();
        TransactionStatus newStatus = TransactionStatus.SUCCESS;

        when(transactionRepository.existsById(id)).thenReturn(true);
        when(transactionRepository.findById(id)).thenReturn(Optional.of(existingTransaction));
        when(transactionRepository.save(any(Transaction.class))).thenAnswer(i -> i.getArguments()[0]);

        Transaction response = transactionService.updateTransactionAmount(id, newStatus);

        assertEquals(newStatus, response.getStatus());
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }

    @Test
    public void deleteTransactionMockTest() {
        Long id = 1L;
        when(transactionRepository.existsById(id)).thenReturn(true);

        boolean isDeleted = transactionService.deleteTransaction(id);

        assertTrue(isDeleted);
        verify(transactionRepository, times(1)).deleteById(id);
    }

    private List<Transaction> getMockTransactions() {
        Faker faker = new Faker();
        List<Transaction> transactions = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            Transaction t = new Transaction();
            t.setId(faker.number().randomNumber());
            t.setAccountId(500L);
            t.setAmount(BigDecimal.valueOf(faker.number().randomDouble(2, 10, 1000)));
            t.setStatus(TransactionStatus.PENDING);
            transactions.add(t);
        }
        return transactions;
    }
}