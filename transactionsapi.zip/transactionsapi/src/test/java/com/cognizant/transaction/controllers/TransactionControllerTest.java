package com.cognizant.transaction.controllers;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.cognizant.transaction.controllers.TransactionController;
import com.cognizant.transaction.dtos.TransactionDTO;
import com.cognizant.transaction.dtos.TransactionResponse;
import com.cognizant.transaction.mappers.TransactionMapper;
import com.cognizant.transaction.models.Transaction;
import com.cognizant.transaction.models.TransactionStatus;
import com.cognizant.transaction.services.TransactionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;

@WebMvcTest(TransactionController.class)
public class TransactionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private TransactionService transactionService;

    @MockitoBean
    private TransactionMapper transactionMapper;

    @Test
    public void testAddTransaction() throws Exception {
    	TransactionDTO dto = new TransactionDTO();
        dto.setAccountId(1L);
        dto.setType("Deposit");
        dto.setAmount(new BigDecimal("500.00"));
        dto.setStatus("PENDING");

        Transaction tx = new Transaction();

        Mockito.when(transactionMapper.toEntity(Mockito.any(TransactionDTO.class))).thenReturn(tx);
        Mockito.when(transactionService.addTransaction(Mockito.any(Transaction.class))).thenReturn(tx);

        mockMvc.perform(post("/transactions/v1.0")
                .with(jwt().authorities(() -> "SCOPE_developer"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
            .andExpect(status().isCreated())
            .andDo(print());
    }

    @Test
    public void testGetAllTransactions() throws Exception {
        List<Transaction> txList = getMockTransactions(3);
        List<TransactionResponse> responses = new ArrayList<>();

        Mockito.when(transactionService.getAllTransactions()).thenReturn(txList);
        Mockito.when(transactionMapper.toDTOs(txList)).thenReturn(responses);

        mockMvc.perform(get("/transactions/v1.0")
                .with(jwt().authorities(() -> "SCOPE_tester")))
            .andExpect(status().isOk());
    }

    @Test
    public void testGetTransactionById() throws Exception {
        Long id = 1L;
        Transaction tx = new Transaction();

        Mockito.when(transactionService.getTransactionById(id)).thenReturn(tx);

        mockMvc.perform(get("/transactions/v1.0/{id}", id)
                .with(jwt().authorities(() -> "SCOPE_developer")))
            .andExpect(status().isAccepted());
    }

    @Test
    public void testGetByAccountId() throws Exception {
        Long accountId = 101L;
        List<Transaction> txs = getMockTransactions(2);
        
        Mockito.when(transactionService.getTransactionsByAccountId(accountId)).thenReturn(txs);
        Mockito.when(transactionMapper.toDTOs(txs)).thenReturn(new ArrayList<>());

        mockMvc.perform(get("/transactions/v1.0/search")
                .param("accountId", accountId.toString())
                .with(jwt().authorities(() -> "SCOPE_tester")))
            .andExpect(status().isOk());
    }

    @Test
    public void testUpdateTransactionStatus() throws Exception {
        Long id = 1L;
        TransactionStatus status = TransactionStatus.SUCCESS;
        Transaction updatedTx = new Transaction();

        Mockito.when(transactionService.updateTransactionAmount(id, status)).thenReturn(updatedTx);

        mockMvc.perform(patch("/transactions/v1.0")
                .param("id", id.toString())
                .param("status", status.name())
                .with(jwt().authorities(() -> "SCOPE_developer")))
            .andExpect(status().isAccepted());
    }

    @Test
    public void testDeleteTransaction_Success() throws Exception {
        Long id = 1L;
        Mockito.when(transactionService.deleteTransaction(id)).thenReturn(true);

        mockMvc.perform(delete("/transactions/v1.0")
                .param("id", id.toString())
                .with(jwt().authorities(() -> "SCOPE_developer")))
            .andExpect(status().isAccepted());
    }

    @Test
    public void testDeleteTransaction_NotFound() throws Exception {
        Long id = 404L;
        Mockito.when(transactionService.deleteTransaction(id)).thenReturn(false);

        mockMvc.perform(delete("/transactions/v1.0")
                .param("id", id.toString())
                .with(jwt().authorities(() -> "SCOPE_developer")))
            .andExpect(status().isNotFound());
    }

    private List<Transaction> getMockTransactions(int count) {
        Faker faker = new Faker();
        List<Transaction> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Transaction tx = new Transaction();
            tx.setId(faker.number().randomNumber());
            tx.setAmount(new BigDecimal(faker.commerce().price()));
            list.add(tx);
        }
        return list;
    }
}