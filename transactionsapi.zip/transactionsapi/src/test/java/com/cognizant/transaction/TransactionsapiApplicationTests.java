package com.cognizant.transaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
