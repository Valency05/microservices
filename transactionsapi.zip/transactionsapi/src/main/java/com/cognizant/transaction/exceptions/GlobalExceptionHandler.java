package com.cognizant.transaction.exceptions;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cognizant.transaction.dtos.GenericMessage;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(TransactionNullException.class)
	public ResponseEntity<GenericMessage<String>> handleNull(TransactionNullException ex) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new GenericMessage<>(ex.getMessage()));
	}

	@ExceptionHandler(TransactionNotFoundException.class)
	public ResponseEntity<GenericMessage<String>> handleNotFound(TransactionNotFoundException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new GenericMessage<>(ex.getMessage()));
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<GenericMessage<Map<String, String>>> handleValidation(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new LinkedHashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(fe -> errors.put(fe.getField(), fe.getDefaultMessage()));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new GenericMessage<>(errors, "Validation failed"));
	}
	
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<GenericMessage<String>> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(new GenericMessage<>("An unexpected error occurred: " + ex.getMessage()));
	}
}