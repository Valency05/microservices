package com.cognizant.transaction.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.cognizant.transaction.exceptions.TransactionNotFoundException;
import com.cognizant.transaction.exceptions.TransactionNullException;
import com.cognizant.transaction.models.Transaction;
import com.cognizant.transaction.models.TransactionStatus;
import com.cognizant.transaction.repositories.TransactionRepository;

import java.util.List;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private RestClient restClient;
	@Value("${gatewayUrl}")
	private String gatewayUrl;
	@Value("${serviceUrl}")
	private String serviceUrl;

	@Override
	public Transaction addTransaction(Transaction transaction) {
		if (transaction == null)
			throw new TransactionNullException("Transaction object is null");
		if (transaction.getAccountId() <= 0)
			throw new TransactionNullException("accountId is required");
		if (transaction.getAmount() == null || transaction.getAmount().signum() <= 0)
			throw new TransactionNullException("amount must be greater than 0");
		if (transaction.getType() == null)
			throw new TransactionNullException("type is required");
		
		String token = restClient.get().uri(gatewayUrl).retrieve().body(String.class);

		boolean exists = restClient.get()
	            .uri(serviceUrl + "/{id}", transaction.getAccountId())
	            .headers(h -> h.setBearerAuth(token))
	            .retrieve()
	            .onStatus(status -> status.value() == 404, (req, res) -> { }) 
	            .toBodilessEntity()
	            .getStatusCode()
	            .is2xxSuccessful();

		if (!exists)
			throw new TransactionNotFoundException("Account not found with id: " + transaction.getAccountId());

		transaction.setStatus(TransactionStatus.PENDING);
		Transaction saved = transactionRepository.save(transaction);

		return saved;
	}


	@Override
	public List<Transaction> getAllTransactions() {
		return transactionRepository.findAll();
	}

	@Override
	public Transaction getTransactionById(Long id) {
		return transactionRepository.findById(id)
				.orElseThrow(() -> new TransactionNotFoundException("Transaction not found: " + id));
	}

	@Override
	public List<Transaction> getTransactionsByAccountId(Long accountId) {
		
		return transactionRepository.findByAccountId(accountId);
	}

	@Override
	public Transaction updateTransactionAmount(Long id, TransactionStatus status) {
		if (status == null)
			throw new TransactionNullException("Transaction cannot be null.");
		if (!transactionRepository.existsById(id))
			throw new TransactionNotFoundException("Transaction cannot found");

		Transaction transaction = transactionRepository.findById(id).get();
		transaction.setStatus(status);

		return transactionRepository.save(transaction);
	}

	@Override
	public boolean deleteTransaction(Long id) {
		if (transactionRepository.existsById(id)) {
			transactionRepository.deleteById(id);
			return true;
		}
		return false;
	}
}