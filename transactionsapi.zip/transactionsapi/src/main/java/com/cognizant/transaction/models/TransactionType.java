
package com.cognizant.transaction.models;

public enum TransactionType {
	Deposit, Withdrawal, Transfer
}