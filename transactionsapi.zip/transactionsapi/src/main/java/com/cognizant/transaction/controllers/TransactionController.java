package com.cognizant.transaction.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.transaction.dtos.GenericMessage;
import com.cognizant.transaction.dtos.TransactionDTO;
import com.cognizant.transaction.dtos.TransactionResponse;
import com.cognizant.transaction.mappers.TransactionMapper;
import com.cognizant.transaction.models.Transaction;
import com.cognizant.transaction.models.TransactionStatus;
import com.cognizant.transaction.services.TransactionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/transactions")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class TransactionController {

	@Autowired
	private TransactionService transactionService;

	@Autowired
	private TransactionMapper transactionMapper;

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@PostMapping("/v1.0")
	public ResponseEntity<GenericMessage<TransactionResponse>> addTransaction(@Valid @RequestBody TransactionDTO dto) {
		Transaction toSave = transactionMapper.toEntity(dto);
		Transaction saved = transactionService.addTransaction(toSave);
		TransactionResponse response = transactionMapper.toDTO(saved);
		return ResponseEntity.status(HttpStatus.CREATED).body(new GenericMessage<>(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping("/v1.0")
	public List<TransactionResponse> getAllTransactions() {
		return transactionMapper.toDTOs(transactionService.getAllTransactions());
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping("/v1.0/{id}")
	public ResponseEntity<GenericMessage<TransactionResponse>> getTransactionById(@PathVariable("id") Long id) {
		Transaction tx = transactionService.getTransactionById(id);
		TransactionResponse response = transactionMapper.toDTO(tx);
		// mimic your accountapi style:
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage<>(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping(value = "/v1.0/search", params = "accountId")
	public ResponseEntity<GenericMessage<List<TransactionResponse>>> getByAccountId(@RequestParam Long accountId) {
		List<Transaction> txs = transactionService.getTransactionsByAccountId(accountId);
		return ResponseEntity.ok(new GenericMessage<>(transactionMapper.toDTOs(txs)));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@PatchMapping("/v1.0")
	public ResponseEntity<GenericMessage<TransactionResponse>> updateTransactionAmount(@RequestParam Long id,
			@RequestParam TransactionStatus status) {
		Transaction updated = transactionService.updateTransactionAmount(id, status);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage<>(transactionMapper.toDTO(updated)));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@DeleteMapping("/v1.0")
	public ResponseEntity<GenericMessage<Long>> deleteTransaction(@RequestParam Long id) {
		boolean deleted = transactionService.deleteTransaction(id);
		if (deleted) {
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage<>(id));
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new GenericMessage<>(id));
		}
	}
}
