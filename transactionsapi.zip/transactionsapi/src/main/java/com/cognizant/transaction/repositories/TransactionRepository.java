package com.cognizant.transaction.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.transaction.models.Transaction;
import com.cognizant.transaction.models.TransactionStatus;
import com.cognizant.transaction.models.TransactionType;

import java.time.OffsetDateTime;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

	List<Transaction> findByAccountId(Long accountId);

	List<Transaction> findByAccountIdAndTransactionDateBetween(Long accountId, OffsetDateTime from, OffsetDateTime to);

	List<Transaction> findByAccountIdAndTypeAndStatus(Long accountId, TransactionType type, TransactionStatus status);
}