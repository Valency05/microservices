package com.cognizant.transaction.mappers;

import java.util.List;

import org.mapstruct.Mapper;

import com.cognizant.transaction.dtos.TransactionDTO;
import com.cognizant.transaction.dtos.TransactionResponse;
import com.cognizant.transaction.models.Transaction;

@Mapper(componentModel = "spring")
public interface TransactionMapper {

	Transaction toEntity(TransactionDTO dto);

	TransactionResponse toDTO(Transaction entity);

	List<TransactionResponse> toDTOs(List<Transaction> entities);
}