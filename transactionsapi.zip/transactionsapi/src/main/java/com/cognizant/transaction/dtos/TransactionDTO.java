package com.cognizant.transaction.dtos;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class TransactionDTO {

	@NotNull
	@Positive
	private Long accountId;

	@NotBlank
	@Pattern(regexp = "Deposit|Withdrawal|Transfer", message = "type must be one of Deposit|Withdrawal|Transfer")
	private String type;

	@NotNull
	@DecimalMin(value = "0.01", message = "amount must be greater than 0")
	private BigDecimal amount;
	
	@NotBlank
	@Pattern(regexp = "PENDING|SUCCESS|FAILED|CANCELLED", message = "status must be one of PENDING|SUCCESS|FAILED|CANCELLED")
	private String status;
}