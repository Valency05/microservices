package com.cognizant.transaction.services;

import java.util.List;

import com.cognizant.transaction.models.Transaction;
import com.cognizant.transaction.models.TransactionStatus;

public interface TransactionService {
	Transaction addTransaction(Transaction transaction);

	List<Transaction> getAllTransactions();

	Transaction getTransactionById(Long id);

	List<Transaction> getTransactionsByAccountId(Long accountId);

	Transaction updateTransactionAmount(Long id, TransactionStatus status);

	boolean deleteTransaction(Long id);
}