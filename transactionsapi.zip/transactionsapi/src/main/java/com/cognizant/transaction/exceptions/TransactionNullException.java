package com.cognizant.transaction.exceptions;

import java.io.Serializable;

public class TransactionNullException extends RuntimeException implements Serializable{
	public TransactionNullException(String message) {
		super(message);
	}
}