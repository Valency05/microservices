package com.cognizant.transaction.exceptions;

import java.io.Serializable;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class ConflictException extends RuntimeException implements Serializable{
	public ConflictException(String message) {
		super(message);
	}
}