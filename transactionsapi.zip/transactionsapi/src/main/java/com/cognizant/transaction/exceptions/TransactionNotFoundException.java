package com.cognizant.transaction.exceptions;

import java.io.Serializable;

public class TransactionNotFoundException extends RuntimeException implements Serializable{
	public TransactionNotFoundException(String message) {
		super(message);
	}
}