package com.cognizant.transaction.dtos;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import com.cognizant.transaction.models.TransactionStatus;
import com.cognizant.transaction.models.TransactionType;

public record TransactionResponse(Long id, Long accountId, TransactionType type, BigDecimal amount,
		OffsetDateTime transactionDate, TransactionStatus status) {

}