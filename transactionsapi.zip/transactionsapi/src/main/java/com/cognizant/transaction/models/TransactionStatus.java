package com.cognizant.transaction.models;

public enum TransactionStatus {
	PENDING, SUCCESS, FAILED, CANCELLED
}
