package com.cognizant.customer.services;

import java.util.List;
import com.cognizant.customer.entities.Customer;

public interface CustomerService {
	Customer addCustomer(Customer customer);
	List<Customer> getAllCustomers();
	Customer getCustomerById(long id);
	Customer getCustomerByEmail(String email);
	Customer updateCustomer(long id, long phone, String email);
	boolean deleteCustomer(long id);	
}