package com.cognizant.customer.exceptions;

import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cognizant.customer.dtos.GenericMessage;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(CustomerNullException.class)
    public ResponseEntity<GenericMessage<String>> handleCustomerNullException(CustomerNullException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new GenericMessage<String>(ex.getMessage()));
    }

    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<GenericMessage<String>> handleCustomerNotFoundException(CustomerNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new GenericMessage<String>(ex.getMessage()));
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<GenericMessage<String>> handleValidationException(MethodArgumentNotValidException ex) {
        // Collects all errors into a single string: "firstName: First name cannot be null, email: Invalid email"
        String errorMessage = ex.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining(", "));

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST) 
                .body(new GenericMessage<String>(errorMessage));
    }
    @ExceptionHandler(RuntimeException.class)
	public ResponseEntity<GenericMessage<String>> handleRuntimeException
	(RuntimeException ex) {
		
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(new GenericMessage<>(ex.getMessage()));
	}
}