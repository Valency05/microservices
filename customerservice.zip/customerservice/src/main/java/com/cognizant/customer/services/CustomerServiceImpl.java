package com.cognizant.customer.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.customer.entities.Customer;
import com.cognizant.customer.exceptions.CustomerNotFoundException;
import com.cognizant.customer.exceptions.CustomerNullException;
import com.cognizant.customer.repositories.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer addCustomer(Customer customer) {
		if (customer == null) {
			throw new CustomerNullException("Customer object is null");
		}
		if (customer.getEmail() != null && customerRepository.existsByEmail(customer.getEmail())) {
			throw new CustomerNullException("Email already registered");
		}
		return customerRepository.save(customer);
	}
 
	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public Customer getCustomerById(long id) {
		return customerRepository.findById(id)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + id));
	}

	@Override
	public Customer getCustomerByEmail(String email) {
		return customerRepository.findByEmail(email)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found with email: " + email));
	}

	@Override
	public Customer updateCustomer(long id, long phone, String email) {
		if (!customerRepository.existsById(id)) {
			throw new CustomerNotFoundException("Customer not found to update");
		}
		Customer c = customerRepository.findById(id).get();

		if (email != null && !email.isBlank() && !email.equalsIgnoreCase(c.getEmail())) {
			if (customerRepository.existsByEmail(email)) {
				throw new CustomerNullException("Email already registered");
			}
			c.setEmail(email);
		}
		if (phone != 0) {
			c.setPhone(phone);
		}
		return customerRepository.save(c);
	}

	@Override
	public boolean deleteCustomer(long id) {
		if (customerRepository.existsById(id)) {
			customerRepository.deleteById(id);
			return true;
		}
		return false;
	}
}