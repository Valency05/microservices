package com.cognizant.customer.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Data 
@NoArgsConstructor 
@AllArgsConstructor 
@Entity // Marks this class as a persistent JPA entity
@Table(name = "customers") 
public class Customer {

    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Uses MySQL AUTO_INCREMENT for ID generation
    private long id;

    @Column(name = "first_name", nullable = false, length = 100) 
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 100) 
    private String lastName;

    @Column(name = "email", nullable = false, length = 100, unique = true) 
    private String email;

    @Column(name = "phone", nullable = false) 
    private long phone;

    @Column(name = "address", nullable = false, length = 250) 
    private String address;

    @CreationTimestamp // Automatically sets the current timestamp on initial record creation
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
}