package com.cognizant.customer.mappers;

import java.util.List;

import org.mapstruct.Mapper;

import com.cognizant.customer.dtos.CustomerDTO;
import com.cognizant.customer.dtos.CustomerResponse;
import com.cognizant.customer.entities.Customer;

@Mapper(componentModel = "spring")
public interface CustomerMapper {
	Customer toEntity(CustomerDTO dto);
	CustomerResponse toDTO(Customer entity);
	List<CustomerResponse> toDTOs(List<Customer> entities);
}