package com.cognizant.customer.exceptions;

public class CustomerNullException extends RuntimeException{
	public CustomerNullException(String message) { 
		super(message); 
	}
}