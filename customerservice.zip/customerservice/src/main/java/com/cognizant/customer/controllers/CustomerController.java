package com.cognizant.customer.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.customer.dtos.CustomerDTO;
import com.cognizant.customer.dtos.CustomerResponse;
import com.cognizant.customer.dtos.GenericMessage;
import com.cognizant.customer.entities.Customer;
import com.cognizant.customer.mappers.CustomerMapper;
import com.cognizant.customer.services.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/customers")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private CustomerMapper customerMapper;

	
	@PostMapping("/v1.0")
	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	public ResponseEntity<GenericMessage<CustomerResponse>> addCustomer(@Valid @RequestBody CustomerDTO dto) {

	    // 1. Use the mapper to convert DTO directly to Entity
	    Customer customer = customerMapper.toEntity(dto);

	    // 2. Perform business logic
	    Customer saved = customerService.addCustomer(customer);
	    
	    // 3. Convert saved entity back to Response DTO
	    CustomerResponse response = customerMapper.toDTO(saved);

	    return ResponseEntity.status(HttpStatus.CREATED).body(new GenericMessage<CustomerResponse>(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping("/v1.0")
	public List<CustomerResponse> getAllCustomers() {
		return customerMapper.toDTOs(customerService.getAllCustomers());
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping("/v1.0/{id}")
	public ResponseEntity<GenericMessage<CustomerResponse>> getCustomerById(@PathVariable("id") Long id) {
		Customer customer = customerService.getCustomerById(id);
		CustomerResponse response = customerMapper.toDTO(customer);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage<CustomerResponse>(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer', 'SCOPE_tester')")
	@GetMapping(value = "/v1.0/email", params = "email")
	public ResponseEntity<GenericMessage<CustomerResponse>> getCustomerByEmail(@RequestParam String email) {
		
		Customer customer = customerService.getCustomerByEmail(email);
		CustomerResponse response=customerMapper.toDTO(customer);
		return ResponseEntity.ok(new GenericMessage<CustomerResponse>(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@PatchMapping("/v1.0")
	public ResponseEntity<GenericMessage<CustomerResponse>> updateCustomerByEmailAndPhone(@RequestParam Long id,
			@RequestParam(required = false) Long phone, @RequestParam(required = false) String email) {

		Customer updated = customerService.updateCustomer(id, phone, email);
		CustomerResponse response=customerMapper.toDTO(updated);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage<CustomerResponse>(response));
	}

	@PreAuthorize("hasAnyAuthority('SCOPE_developer')")
	@DeleteMapping("/v1.0")
	public ResponseEntity<GenericMessage<String>> deleteCustomer(@RequestParam Long id) {
		boolean deleted = customerService.deleteCustomer(id);
		String success="customer with id: "+id+" is deleted";
		
		if (deleted) {
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(new GenericMessage<String>(success));
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new GenericMessage<String>(String.valueOf(id)));
		}
	}
	

}