package com.cognizant.customer.dtos;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class GenericMessage<T> {
	private T object;

	
	public GenericMessage(T object) {
		super();
		this.object = object;
	}
	

}