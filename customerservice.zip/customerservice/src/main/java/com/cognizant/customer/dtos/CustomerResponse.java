package com.cognizant.customer.dtos;

import java.time.LocalDateTime;

public record CustomerResponse(long id, String firstName, String lastName, 
		String email, long phone, String address, LocalDateTime createdAt) {

}