package com.cognizant.customer.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.customer.entities.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

	boolean existsByEmail(String email);
	Optional<Customer> findByEmail(String email);
	
}