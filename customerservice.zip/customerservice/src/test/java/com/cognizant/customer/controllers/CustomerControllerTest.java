package com.cognizant.customer.controllers;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.cognizant.customer.dtos.CustomerDTO;
import com.cognizant.customer.dtos.CustomerResponse;
import com.cognizant.customer.entities.Customer;
import com.cognizant.customer.mappers.CustomerMapper;
import com.cognizant.customer.services.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
@WebMvcTest(CustomerController.class)
public class CustomerControllerTest {

    @MockitoBean
    private CustomerService customerService;

    @MockitoBean
    private CustomerMapper customerMapper;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DisplayName("Add Customer - POST /customers/v1.0")
    public void addCustomerTest() throws Exception {
        Customer customer = getSampleCustomers().get(0);
        
        // Manual DTO creation
        CustomerDTO dto = new CustomerDTO();
        dto.setFirstName(customer.getFirstName());
        dto.setLastName(customer.getLastName());
        dto.setEmail(customer.getEmail());
        dto.setPhone(customer.getPhone());
        dto.setAddress(customer.getAddress());

        CustomerResponse response = new CustomerResponse(
            1L, customer.getFirstName(), customer.getLastName(), 
            customer.getEmail(), customer.getPhone(), customer.getAddress(), LocalDateTime.now()
        );

        Mockito.when(customerService.addCustomer(Mockito.any(Customer.class))).thenReturn(customer);
        Mockito.when(customerMapper.toDTO(Mockito.any(Customer.class))).thenReturn(response);

        mockMvc.perform(post("/customers/v1.0")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto))
                .with(jwt().authorities(() -> "SCOPE_developer")))
                .andExpect(status().isCreated())
                .andDo(print())
                .andExpect(jsonPath("$.object.firstName").value(customer.getFirstName()));
    }

    @Test
    @DisplayName("Delete Customer - DELETE /customers/v1.0")
    public void deleteCustomerTest() throws Exception {
        Mockito.when(customerService.deleteCustomer(1L)).thenReturn(true);

        mockMvc.perform(delete("/customers/v1.0")
                .param("id", "1")
                .with(jwt().authorities(() -> "SCOPE_developer")))
                .andExpect(status().isAccepted())
                // Since the controller returns 'success' string in GenericMessage on success
                .andExpect(jsonPath("$.object").value("customer with id: 1 is deleted"))
                .andDo(print());
    }

    // Helper method refactored to use setters instead of builder
    private List<Customer> getSampleCustomers() {
        List<Customer> customers = new ArrayList<>();
        Faker faker = new Faker();
        for (int i = 0; i < 5; i++) {
            Customer customer = new Customer();
            customer.setId((long) i);
            customer.setFirstName(faker.name().firstName());
            customer.setLastName(faker.name().lastName());
            customer.setEmail(faker.internet().emailAddress());
            customer.setPhone(faker.number().numberBetween(6000000000L, 9999999999L));
            customer.setAddress(faker.address().fullAddress());
            
            customers.add(customer);
        }
        return customers;
    }
}