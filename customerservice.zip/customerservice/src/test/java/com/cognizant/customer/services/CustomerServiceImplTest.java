package com.cognizant.customer.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cognizant.customer.entities.Customer;
import com.cognizant.customer.exceptions.CustomerNotFoundException;
import com.cognizant.customer.exceptions.CustomerNullException;
import com.cognizant.customer.repositories.CustomerRepository;
@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @Test
    void addCustomer_Success() {
        // Manual instantiation instead of builder
        Customer customer = new Customer();
        customer.setEmail("test@mail.com");
        
        when(customerRepository.existsByEmail(anyString())).thenReturn(false);
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);

        Customer result = customerService.addCustomer(customer);

        assertNotNull(result);
        assertEquals("test@mail.com", result.getEmail());
        verify(customerRepository, times(1)).save(customer);
    }

    @Test
    void addCustomer_ThrowsException_WhenEmailExists() {
        Customer customer = new Customer();
        customer.setEmail("exists@mail.com");
        
        when(customerRepository.existsByEmail("exists@mail.com")).thenReturn(true);

        assertThrows(CustomerNullException.class, () -> customerService.addCustomer(customer));
    }

    @Test
    void getCustomerById_ThrowsException_WhenNotFound() {
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> customerService.getCustomerById(1L));
    }

    @Test
    void updateCustomer_Success() {
        // Using setters to prepare existing data
        Customer existing = new Customer();
        existing.setId(1L);
        existing.setEmail("old@mail.com");
        
        when(customerRepository.existsById(1L)).thenReturn(true);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(existing));
        // thenAnswer allows us to return the object that was passed into the save method
        when(customerRepository.save(any(Customer.class))).thenAnswer(i -> i.getArguments()[0]);

        Customer updated = customerService.updateCustomer(1L, 9999999999L, "new@mail.com");

        assertNotNull(updated);
        assertEquals("new@mail.com", updated.getEmail());
        assertEquals(9999999999L, updated.getPhone());
    }
}