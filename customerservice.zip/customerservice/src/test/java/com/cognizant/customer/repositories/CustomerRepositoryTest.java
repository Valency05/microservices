package com.cognizant.customer.repositories;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import com.cognizant.customer.entities.Customer;
import java.util.Optional;

@DataJpaTest
class CustomerRepositoryTest {

    @Autowired
    private CustomerRepository repository;

    @Test
    void testExistsByEmail() {
        // Replaced builder with setters
        Customer customer = new Customer();
        customer.setFirstName("Test");
        customer.setEmail("repo@test.com");
        customer.setPhone(1234567890L);
        customer.setAddress("Test Address"); // Ensure mandatory fields are set
        
        repository.save(customer);

        boolean exists = repository.existsByEmail("repo@test.com");
        assertThat(exists).isTrue();
    }

    @Test
    void testFindByPhone() {
        // Replaced builder with setters
        Customer customer = new Customer();
        customer.setFirstName("John");
        customer.setLastName("Doe");
        customer.setEmail("john@test.com");
        customer.setPhone(8888888888L);
        customer.setAddress("123 Bank St");
        
        repository.save(customer);


    }
}