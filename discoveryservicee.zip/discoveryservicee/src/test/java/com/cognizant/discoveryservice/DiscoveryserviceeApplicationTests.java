package com.cognizant.discoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryserviceeApplicationTests {

	@Test
	void contextLoads() {
	}

}
